//
//  InfoView.swift
//  AtmiyaCard
//
//  Created by Atmiya Jadvani on 17/07/20.
//  Copyright © 2020 Atmiya Jadvani. All rights reserved.
//

import SwiftUI

struct InfoView: View {
    
    let text: String
    let imageName: String
    
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            
            .fill(Color.white)
            .frame(width: 300 , height: 50)
            .overlay(
                HStack {
                    Image(systemName: imageName)
                        .foregroundColor(.green)
                    Text(text)
                        .font(Font.custom("DMSans-Regular", size:17))
            })
            .padding(.all)
    }
}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView(text: "+91 9925331110", imageName: "email.fill")
            .previewLayout(.sizeThatFits)
    }
}

