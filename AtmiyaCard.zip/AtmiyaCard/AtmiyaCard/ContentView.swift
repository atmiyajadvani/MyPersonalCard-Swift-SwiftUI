//
//  ContentView.swift
//  AtmiyaCard
//
//  Created by Atmiya Jadvani on 17/07/20.
//  Copyright © 2020 Atmiya Jadvani. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(UIColor(red: 0.00, green: 0.72, blue: 0.58, alpha: 1.0))
                .edgesIgnoringSafeArea(.all)
            VStack {
                Image("Atmiya")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300, height: 300)
                
                Text("Atmiya Jadvani")
                    .font(Font.custom("DMSans-Medium", size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                Text("iOS Developer")
                    .font(Font.custom("DMSans-Medium", size: 20))
                    .fontWeight(.medium)
                    .foregroundColor(Color.white)
                
                Divider()
                InfoView(text: "+91 9925331110", imageName: "phone.fill")
                InfoView(text: "atmiyajadvani@gmail.com", imageName: "envelope.fill")
            
            }
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


